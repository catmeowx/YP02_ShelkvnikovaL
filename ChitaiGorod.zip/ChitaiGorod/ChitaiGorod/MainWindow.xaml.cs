﻿using ChitaiGorod.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace ChitaiGorod
{
    public partial class MainWindow : Window
    {
        private User? _user;
        private bool _isGuest;
        private List<ProductCard> _allCards = new List<ProductCard>();

        public MainWindow(User? user, bool isGuest)
        {
            InitializeComponent();
            _user = user;
            _isGuest = isGuest;

            SetupUIByRole();
            LoadProducts();
        }

        // настраиваем видимость кнопок в зависимости от роли
        private void SetupUIByRole()
        {
            // если гость, показываем только это и выходим
            if (_isGuest || _user == null)
            {
                tbUserInfo.Text = "Режим: Гость";
                return;
            }

            // настройки для авторизованных пользователей
            string roleName = _user.Role?.Rolename ?? "Неизвестная роль";
            tbUserInfo.Text = $"{_user.Fullname} ({roleName})";

            // менеджер и админ видят поиск, фильтры и заказы
            if (_user.Roleid <= 2)
            {
                txtSearch.Visibility = Visibility.Visible;
                spFilters.Visibility = Visibility.Visible;
                cmbFilterDiscount.Visibility = Visibility.Visible;
                cmbSortPrice.Visibility = Visibility.Visible;
                cmbSortQty.Visibility = Visibility.Visible;
                btnOrders.Visibility = Visibility.Visible;
            }

            // только админ может добавлять и удалять товары
            if (_user.Roleid == 1)
            {
                btnAddProduct.Visibility = Visibility.Visible;
                btnDeleteProduct.Visibility = Visibility.Visible;
            }
        }

        // загружаем товары со всеми связанными таблицами
        private void LoadProducts()
        {
            using var db = new ChitaiGorodContext();

            var products = db.Products
                .Include(p => p.Category)
                .Include(p => p.Manufacturer)
                .Include(p => p.Supplier)
                .Include(p => p.Unit)
                .ToList();

            _allCards = products.Select(p => new ProductCard(p)).ToList();

            // сохраняем текущий выбранный элемент
            var selectedItem = lbProducts.SelectedItem;

            // обновляем список
            lbProducts.ItemsSource = null;
            lbProducts.ItemsSource = _allCards;

            // восстанавливаем выделение если нужно
            if (selectedItem != null)
                lbProducts.SelectedItem = selectedItem;
        }

        // открываем окно заказов
        private void BtnOrders_Click(object sender, RoutedEventArgs e)
        {
            var ordersWin = new OrdersWindow(_user);
            ordersWin.Show();
        }

        // редактирование доступно только админу
        private void LbProducts_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (_user?.Roleid == 1 && lbProducts.SelectedItem is ProductCard card)
            {
                OpenEditWindow(card.P);
            }
        }

        // передаем null, так как создаем новый товар
        private void BtnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            OpenEditWindow(null);
        }

        private void BtnDeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (lbProducts.SelectedItem is not ProductCard selectedCard)
            {
                MessageBox.Show("Выберите товар для удаления!", "Предупреждение",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var result = MessageBox.Show(
                $"Вы действительно хотите удалить товар \"{selectedCard.Productname}\"?\nЭто действие нельзя отменить.",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes) return;

            try
            {
                using var db = new ChitaiGorodContext();

                // проверяем, есть ли этот товар в заказах, удалять нельзя если есть
                bool isInOrders = db.Orderitems.Any(oi => oi.Productid == selectedCard.P.Productid);
                if (isInOrders)
                {
                    MessageBox.Show("Нельзя удалить этот товар! Он присутствует в одном или нескольких заказах.",
                        "Ошибка удаления", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // удаляем файл картинки с диска, если это не заглушка
                if (!string.IsNullOrEmpty(selectedCard.P.Photo) && selectedCard.P.Photo != "picture.png")
                {
                    string photoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "img", selectedCard.P.Photo);
                    if (File.Exists(photoPath)) File.Delete(photoPath);
                }

                // удаляем запись из базы данных
                db.Products.Remove(selectedCard.P);
                db.SaveChanges();

                MessageBox.Show("Товар успешно удален!", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            var login = new LoginWindow();
            login.Show();
            this.Close();
        }

        // применяем поиск, фильтры и сортировку одновременно
        private void ApplyFiltersAndSort()
        {
            if (lbProducts == null || _allCards == null || _allCards.Count == 0)
                return;

            IEnumerable<ProductCard> result = _allCards.ToList();

            // применяем поиск по тексту
            string search = txtSearch?.Text?.ToLower().Trim();
            if (!string.IsNullOrEmpty(search))
            {
                result = result.Where(c =>
                    c.Productname.ToLower().Contains(search) ||
                    c.Article.ToLower().Contains(search) ||
                    (c.Description != null && c.Description.ToLower().Contains(search)) ||
                    (c.Manufacturer?.Manufacturername != null && c.Manufacturer.Manufacturername.ToLower().Contains(search))
                );
            }

            // фильтруем по выбранной скидке
            int discountIndex = cmbFilterDiscount?.SelectedIndex ?? 0;
            if (discountIndex == 1)
                result = result.Where(c => c.Discount >= 0 && c.Discount <= 12.99m);
            else if (discountIndex == 2)
                result = result.Where(c => c.Discount >= 13 && c.Discount <= 16.99m);
            else if (discountIndex == 3)
                result = result.Where(c => c.Discount >= 17);

            // сортируем по цене
            int priceSortIndex = cmbSortPrice?.SelectedIndex ?? 0;
            if (priceSortIndex == 1)
                result = result.OrderBy(c => c.Price);
            else if (priceSortIndex == 2)
                result = result.OrderByDescending(c => c.Price);

            // сортируем по количеству
            int qtySortIndex = cmbSortQty?.SelectedIndex ?? 0;
            if (qtySortIndex == 1)
                result = result.OrderBy(c => c.Quantity);
            else if (qtySortIndex == 2)
                result = result.OrderByDescending(c => c.Quantity);

            // сохраняем текущий выбранный элемент
            var selectedItem = lbProducts.SelectedItem;

            // обновляем список на экране
            lbProducts.ItemsSource = null;
            lbProducts.ItemsSource = result.ToList();

            // восстанавливаем выделение
            if (selectedItem != null)
                lbProducts.SelectedItem = selectedItem;
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFiltersAndSort();
        }

        private void CmbFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFiltersAndSort();
        }

        private void CmbSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFiltersAndSort();
        }

        private void OpenEditWindow(Product? product)
        {
            var editWindow = new EditProductWindow(product);
            // если в окне редактирования нажали сохранить, обновляем список
            if (editWindow.ShowDialog() == true)
            {
                LoadProducts();
            }
        }
    }

    // вспомогательный класс для удобного вывода данных в карточке
    public class ProductCard
    {
        public Product P { get; } // хранит сам объект товара из бд
        public ProductCard(Product product) => P = product;

        public string Article => P.Article;
        public string Productname => P.Productname;
        public string? Description => P.Description;
        public decimal Price => P.Price;
        public decimal Discount => P.Discount;
        public int Quantity => P.Quantity;

        public Category? Category => P.Category;
        public Manufacturer? Manufacturer => P.Manufacturer;
        public Supplier? Supplier => P.Supplier;
        public Unit? Unit => P.Unit;

        // есть ли скидка больше 0
        public bool HasDiscount => Discount > 0;

        // расчет конечной цены с округлением до 2 знаков
        public decimal FinalPrice
        {
            get
            {
                if (Discount > 0)
                    return Math.Round(Price * (1 - Discount / 100m), 2);
                return Price;
            }
        }

        // путь к картинке, проверяем существует ли файл
        public string FullPhotoPath
        {
            get
            {
                if (string.IsNullOrEmpty(P.Photo))
                    return "img/picture.png";
                string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "img", P.Photo);
                return File.Exists(path) ? path : "img/picture.png";
            }
        }

        // цвет строки по заданию: серый если 0, бирюзовый если скидка > 25
        public SolidColorBrush RowColor
        {
            get
            {
                if (Quantity == 0)
                    return Brushes.LightGray;
                if (Discount > 25)
                    return new SolidColorBrush((Color)ColorConverter.ConvertFromString("#23E1EF"));
                return Brushes.White;
            }
        }
    }
}