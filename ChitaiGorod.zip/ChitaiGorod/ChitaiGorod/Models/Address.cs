﻿using System;
using System.Collections.Generic;

namespace ChitaiGorod.Models;

public partial class Address
{
    public int Pickuppointid { get; set; }

    public string Postalcode { get; set; } = null!;

    public int Cityid { get; set; }

    public int Streetid { get; set; }

    public string Housenumber { get; set; } = null!;

    public virtual City City { get; set; } = null!;

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();

    public virtual Street Street { get; set; } = null!;
}
