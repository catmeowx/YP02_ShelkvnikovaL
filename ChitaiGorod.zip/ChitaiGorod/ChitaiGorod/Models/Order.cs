﻿using System;
using System.Collections.Generic;

namespace ChitaiGorod.Models;

public partial class Order
{
    public int Orderid { get; set; }

    public DateOnly Orderdate { get; set; }

    public DateOnly Deliverydate { get; set; }

    public int Pickuppointid { get; set; }

    public int Userid { get; set; }

    public string Pickupcode { get; set; } = null!;

    public int Statusid { get; set; }

    public virtual ICollection<Orderitem> Orderitems { get; set; } = new List<Orderitem>();

    public virtual Address Pickuppoint { get; set; } = null!;

    public virtual Status Status { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
