﻿using System;
using System.Collections.Generic;

namespace ChitaiGorod.Models;

public partial class Street
{
    public int Streetid { get; set; }

    public string Streetname { get; set; } = null!;

    public int Cityid { get; set; }

    public virtual ICollection<Address> Addresses { get; set; } = new List<Address>();

    public virtual City City { get; set; } = null!;
}
