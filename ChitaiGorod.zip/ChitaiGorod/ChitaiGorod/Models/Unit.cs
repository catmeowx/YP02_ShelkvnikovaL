﻿using System;
using System.Collections.Generic;

namespace ChitaiGorod.Models;

public partial class Unit
{
    public int Unitid { get; set; }

    public string Unitname { get; set; } = null!;

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
