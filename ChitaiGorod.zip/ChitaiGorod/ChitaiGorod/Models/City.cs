﻿using System;
using System.Collections.Generic;

namespace ChitaiGorod.Models;

public partial class City
{
    public int Cityid { get; set; }

    public string Cityname { get; set; } = null!;

    public virtual ICollection<Address> Addresses { get; set; } = new List<Address>();

    public virtual ICollection<Street> Streets { get; set; } = new List<Street>();
}
