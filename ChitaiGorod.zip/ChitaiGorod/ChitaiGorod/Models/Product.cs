﻿using System;
using System.Collections.Generic;

namespace ChitaiGorod.Models;

public partial class Product
{
    public int Productid { get; set; }

    public string Article { get; set; } = null!;

    public string Productname { get; set; } = null!;

    public int Categoryid { get; set; }

    public int Manufacturerid { get; set; }

    public int Supplierid { get; set; }

    public int Unitid { get; set; }

    public decimal Price { get; set; }

    public decimal Discount { get; set; }

    public int Quantity { get; set; }

    public string? Description { get; set; }

    public string? Photo { get; set; }

    public virtual Category Category { get; set; } = null!;

    public virtual Manufacturer Manufacturer { get; set; } = null!;

    public virtual ICollection<Orderitem> Orderitems { get; set; } = new List<Orderitem>();

    public virtual Supplier Supplier { get; set; } = null!;

    public virtual Unit Unit { get; set; } = null!;
}
