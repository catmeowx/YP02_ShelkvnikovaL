﻿using ChitaiGorod.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace ChitaiGorod
{
    /// <summary>
    /// Логика взаимодействия для OrdersWindow.xaml
    /// </summary>
    public partial class OrdersWindow : Window
    {
        private User _currentUser;
        private List<Order> _allOrders = new List<Order>();

        public OrdersWindow(User user)
        {
            InitializeComponent();
            _currentUser = user;

            // Кнопка добавления только для Админа
            if (_currentUser.Roleid == 1)
                btnAddOrder.Visibility = Visibility.Visible;

            LoadOrders();
        }

        private void LoadOrders()
        {
            using var db = new ChitaiGorodContext();

            _allOrders = db.Orders
                .Include(o => o.User)
                .Include(o => o.Pickuppoint)
                .Include(o => o.Status)
                .OrderByDescending(o => o.Orderid)
                .ToList();

            dgOrders.ItemsSource = _allOrders;
        }

        private void DgOrders_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            // Редактировать может только Админ
            if (_currentUser.Roleid == 1 && dgOrders.SelectedItem is Order order)
            {
                OpenEditOrderWindow(order);
            }
        }

        private void BtnAddOrder_Click(object sender, RoutedEventArgs e)
        {
            OpenEditOrderWindow(null);
        }

        private void OpenEditOrderWindow(Order? order)
        {
            var editWin = new EditOrderWindow(order);
            if (editWin.ShowDialog() == true)
            {
                LoadOrders(); // Обновляем список после сохранения
            }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
