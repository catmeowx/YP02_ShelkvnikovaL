﻿using ChitaiGorod.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Windows;

namespace ChitaiGorod
{
    public partial class EditOrderWindow : Window
    {
        private Order? _order; // хранит текущий заказ

        public EditOrderWindow(Order? order)
        {
            InitializeComponent();
            _order = order;

            // меняем заголовок окна в зависимости от режима
            tbTitle.Text = _order == null ? "Добавление заказа" : "Редактирование заказа";

            LoadDictionaries();
            FillFields();
        }

        // загружаем данные в выпадающие списки
        private void LoadDictionaries()
        {
            using var db = new ChitaiGorodContext();

            cmbUser.ItemsSource = db.Users.ToList();
            cmbUser.DisplayMemberPath = "Fullname";
            cmbUser.SelectedValuePath = "Userid";

            cmbPickup.ItemsSource = db.Addresses.ToList();
            cmbPickup.DisplayMemberPath = "Postalcode";
            cmbPickup.SelectedValuePath = "Pickuppointid";

            cmbStatus.ItemsSource = db.Statuses.ToList();
            cmbStatus.DisplayMemberPath = "Statusname";
            cmbStatus.SelectedValuePath = "Statusid";
        }

        // заполняем поля если это редактирование, иначе ставим даты по умолчанию
        private void FillFields()
        {
            if (_order != null)
            {
                cmbUser.SelectedValue = _order.Userid;
                cmbPickup.SelectedValue = _order.Pickuppointid;
                cmbStatus.SelectedValue = _order.Statusid;
                dpOrderDate.SelectedDate = _order.Orderdate.ToDateTime(TimeOnly.MinValue);
                dpDeliveryDate.SelectedDate = _order.Deliverydate.ToDateTime(TimeOnly.MinValue);
                txtPickupCode.Text = _order.Pickupcode;
            }
            else
            {
                dpOrderDate.SelectedDate = DateTime.Today;
                dpDeliveryDate.SelectedDate = DateTime.Today.AddDays(7);
                txtPickupCode.Text = GeneratePickupCode();
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            // проверка что выбраны все обязательные поля
            if (cmbUser.SelectedValue == null || cmbPickup.SelectedValue == null || cmbStatus.SelectedValue == null)
            {
                MessageBox.Show("Заполните все обязательные поля!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // проверка что даты выбраны
            if (dpOrderDate.SelectedDate == null || dpDeliveryDate.SelectedDate == null)
            {
                MessageBox.Show("Выберите даты заказа и доставки!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using var db = new ChitaiGorodContext();

                if (_order == null)
                {
                    // создаем новый заказ
                    var newOrder = new Order
                    {
                        Userid = (int)cmbUser.SelectedValue,
                        Pickuppointid = (int)cmbPickup.SelectedValue,
                        Statusid = (int)cmbStatus.SelectedValue,
                        Orderdate = DateOnly.FromDateTime(dpOrderDate.SelectedDate.Value),
                        Deliverydate = DateOnly.FromDateTime(dpDeliveryDate.SelectedDate.Value),
                        Pickupcode = txtPickupCode.Text.Trim()
                    };
                    db.Orders.Add(newOrder);
                }
                else
                {
                    // если редактируем старый, то ищем его в бд по айди чтобы ef отслеживал изменения
                    var orderToUpdate = db.Orders.FirstOrDefault(o => o.Orderid == _order.Orderid);

                    if (orderToUpdate != null)
                    {
                        orderToUpdate.Userid = (int)cmbUser.SelectedValue;
                        orderToUpdate.Pickuppointid = (int)cmbPickup.SelectedValue;
                        orderToUpdate.Statusid = (int)cmbStatus.SelectedValue;
                        orderToUpdate.Orderdate = DateOnly.FromDateTime(dpOrderDate.SelectedDate.Value);
                        orderToUpdate.Deliverydate = DateOnly.FromDateTime(dpDeliveryDate.SelectedDate.Value);
                        orderToUpdate.Pickupcode = txtPickupCode.Text.Trim();
                    }
                    else
                    {
                        MessageBox.Show("Ошибка: заказ не найден в базе данных.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }

                // сохраняем изменения в базу
                db.SaveChanges();

                // сообщаем главному окну что все ок
                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            // закрываем окно без сохранения
            DialogResult = false;
        }

        // генерируем случайный 3-значный код для получения
        private string GeneratePickupCode()
        {
            Random rnd = new Random();
            return rnd.Next(100, 999).ToString();
        }
    }
}