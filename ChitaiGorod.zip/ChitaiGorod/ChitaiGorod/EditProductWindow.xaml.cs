﻿using ChitaiGorod.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace ChitaiGorod
{
    public partial class EditProductWindow : Window
    {
        private Product? _product; // хранит текущий товар, если null значит создаем новый
        private string? _newPhotoPath; // путь к новому фото

        public EditProductWindow(Product? product)
        {
            InitializeComponent();
            _product = product;

            // меняем заголовок окна в зависимости от режима
            tbTitle.Text = _product == null ? "Добавление товара" : "Редактирование товара";

            LoadDictionaries();
            FillFields();
        }

        // загружаем данные в выпадающие списки
        private void LoadDictionaries()
        {
            using var db = new ChitaiGorodContext();

            cmbCategory.ItemsSource = db.Categories.ToList();
            cmbCategory.DisplayMemberPath = "Categoryname";
            cmbCategory.SelectedValuePath = "Categoryid";

            cmbManufacturer.ItemsSource = db.Manufacturers.ToList();
            cmbManufacturer.DisplayMemberPath = "Manufacturername";
            cmbManufacturer.SelectedValuePath = "Manufacturerid";

            cmbSupplier.ItemsSource = db.Suppliers.ToList();
            cmbSupplier.DisplayMemberPath = "Suppliername";
            cmbSupplier.SelectedValuePath = "Supplierid";

            cmbUnit.ItemsSource = db.Units.ToList();
            cmbUnit.DisplayMemberPath = "Unitname";
            cmbUnit.SelectedValuePath = "Unitid";
        }

        // заполняем поля если это редактирование, иначе ставим заглушку
        private void FillFields()
        {
            if (_product != null)
            {
                txtName.Text = _product.Productname;
                txtDesc.Text = _product.Description;
                txtPrice.Text = _product.Price.ToString();
                txtDiscount.Text = _product.Discount.ToString();
                txtQuantity.Text = _product.Quantity.ToString();

                cmbCategory.SelectedValue = _product.Categoryid;
                cmbManufacturer.SelectedValue = _product.Manufacturerid;
                cmbSupplier.SelectedValue = _product.Supplierid;
                cmbUnit.SelectedValue = _product.Unitid;

                // формируем полный путь к фото вручную, так как в классе Product этого свойства нет
                string photoFileName = string.IsNullOrEmpty(_product.Photo) ? "picture.png" : _product.Photo;
                string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "img", photoFileName);

                if (File.Exists(fullPath))
                {
                    imgPreview.Source = new BitmapImage(new Uri(fullPath, UriKind.Absolute));
                }
                else
                {
                    // если файла нет, показываем заглушку
                    imgPreview.Source = new BitmapImage(new Uri("img/picture.png", UriKind.Relative));
                }

                _newPhotoPath = _product.Photo; // сохраняем имя текущего фото
            }
            else
            {
                // для нового товара ставим заглушку
                imgPreview.Source = new BitmapImage(new Uri("img/picture.png", UriKind.Relative));
                _newPhotoPath = null;
            }
        }

        // загрузка фото через диалоговое окно
        private void BtnLoadPhoto_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Изображения|*.jpg;*.jpeg;*.png",
                Title = "Выберите изображение товара"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    var img = new BitmapImage();
                    img.BeginInit();
                    img.UriSource = new Uri(dialog.FileName, UriKind.Absolute);
                    img.DecodePixelWidth = 300; // ограничиваем ширину для оптимизации
                    img.EndInit();

                    imgPreview.Source = img;
                    _newPhotoPath = Path.GetFileName(dialog.FileName); // сохраняем только имя файла

                    // копируем файл в папку img рядом с exe
                    string destPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "img", _newPhotoPath);
                    File.Copy(dialog.FileName, destPath, true);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки фото: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        // разрешаем вводить только цифры и точку
        private void TxtNumber_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!char.IsDigit(e.Text, 0) && e.Text != "." && e.Text != ",")
            {
                e.Handled = true;
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            // проверка заполненности полей
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите наименование товара!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!decimal.TryParse(txtPrice.Text, out decimal price) || price < 0)
            {
                MessageBox.Show("Некорректная цена! Введите положительное число.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(txtQuantity.Text, out int quantity) || quantity < 0)
            {
                MessageBox.Show("Некорректное количество! Введите целое неотрицательное число.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (cmbCategory.SelectedValue == null || cmbManufacturer.SelectedValue == null ||
                cmbSupplier.SelectedValue == null || cmbUnit.SelectedValue == null)
            {
                MessageBox.Show("Выберите все справочные поля (категория, производитель, поставщик, ед. изм.)!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using var db = new ChitaiGorodContext();

                if (_product == null)
                {
                    // создание нового товара

                    // вычисляем следующий id вручную, чтобы избежать ошибки sequence в бд
                    int maxId = db.Products.Any() ? db.Products.Max(p => p.Productid) : 0;
                    int newId = maxId + 1;

                    // генерируем уникальный артикул
                    string newArticle = $"ART-{DateTime.Now:yyyyMMddHHmmss}";

                    // безопасное приведение типов
                    int catId = Convert.ToInt32(cmbCategory.SelectedValue);
                    int manId = Convert.ToInt32(cmbManufacturer.SelectedValue);
                    int supId = Convert.ToInt32(cmbSupplier.SelectedValue);
                    int unitId = Convert.ToInt32(cmbUnit.SelectedValue);

                    var newProduct = new Product
                    {
                        Productid = newId, // явно задаем вычисленный id
                        Article = newArticle,
                        Productname = txtName.Text.Trim(),
                        Description = txtDesc.Text?.Trim(),
                        Price = price,
                        Discount = decimal.TryParse(txtDiscount.Text, out var disc) ? disc : 0,
                        Quantity = quantity,
                        Categoryid = catId,
                        Manufacturerid = manId,
                        Supplierid = supId,
                        Unitid = unitId,
                        Photo = _newPhotoPath ?? "picture.png"
                    };

                    db.Products.Add(newProduct);
                }
                else
                {
                    // редактирование существующего товара

                    // ищем этот же товар в текущем подключении к бд, чтобы ef отслеживал изменения
                    var productToUpdate = db.Products.FirstOrDefault(p => p.Productid == _product.Productid);

                    if (productToUpdate != null)
                    {
                        productToUpdate.Productname = txtName.Text.Trim();
                        productToUpdate.Description = txtDesc.Text?.Trim();
                        productToUpdate.Price = price;
                        productToUpdate.Discount = decimal.TryParse(txtDiscount.Text, out var disc) ? disc : 0;
                        productToUpdate.Quantity = quantity;

                        // обновляем внешние ключи
                        productToUpdate.Categoryid = Convert.ToInt32(cmbCategory.SelectedValue);
                        productToUpdate.Manufacturerid = Convert.ToInt32(cmbManufacturer.SelectedValue);
                        productToUpdate.Supplierid = Convert.ToInt32(cmbSupplier.SelectedValue);
                        productToUpdate.Unitid = Convert.ToInt32(cmbUnit.SelectedValue);

                        // если загружали новое фото - обновляем путь и удаляем старое
                        if (!string.IsNullOrEmpty(_newPhotoPath) && _newPhotoPath != productToUpdate.Photo)
                        {
                            // удаляем старое фото, если оно не системная заглушка
                            if (!string.IsNullOrEmpty(productToUpdate.Photo) && productToUpdate.Photo != "picture.png")
                            {
                                string oldPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "img", productToUpdate.Photo);
                                if (File.Exists(oldPath)) File.Delete(oldPath);
                            }
                            productToUpdate.Photo = _newPhotoPath;
                        }
                    }
                }

                // сохраняем изменения в базу
                db.SaveChanges();

                // сообщаем главному окну что все ок
                DialogResult = true;
            }
            catch (Exception ex)
            {
                // выводим innerexception, там обычно настоящая причина ошибки от бд
                string errorMsg = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                MessageBox.Show($"Ошибка сохранения: {errorMsg}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            // закрываем окно без сохранения
            DialogResult = false;
        }

        // простая генерация артикула
        private string GenerateNewArticle()
        {
            using var db = new ChitaiGorodContext();
            int maxId = db.Products.Any() ? db.Products.Max(p => p.Productid) + 1 : 1;
            return $"ART-{maxId:D4}";
        }
    }
}