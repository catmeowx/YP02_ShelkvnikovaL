﻿using ChitaiGorod.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Windows;

namespace ChitaiGorod
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            using var db = new ChitaiGorodContext();

            var user = db.Users
                .Include(u => u.Role)
                .FirstOrDefault(u => u.Login == tbLogin.Text && u.Password == pbPassword.Password);

            if (user != null)
            {
                MainWindow mainWin = new MainWindow(user, false);
                mainWin.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnGuest_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWin = new MainWindow(null, true);
            mainWin.Show();
            this.Close();
        }
    }
}